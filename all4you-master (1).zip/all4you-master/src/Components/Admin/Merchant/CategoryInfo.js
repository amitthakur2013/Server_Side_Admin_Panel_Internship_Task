import React, { Fragment } from "react";

const CategoryInfo = () => {
  return (
    <Fragment>
      {/* Category */}
      {/* Subcategory */}
    </Fragment>
  );
};

export default CategoryInfo;
