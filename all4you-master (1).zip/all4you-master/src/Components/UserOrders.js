import React from "react";
import UserOrderCard from "./UserOrderCard";
const UserOrders = () => {
  return (
    <>
      <UserOrderCard />
      <UserOrderCard />
    </>
  );
};

export default UserOrders;
