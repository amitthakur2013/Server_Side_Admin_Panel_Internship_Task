import React from "react";

const UserCredits = () => {
  return (
    <>
      <h1>Credits</h1>
    </>
  );
};

export default UserCredits;
