import React from "react";

const UserRefer = () => {
  return (
    <>
      <h1>Refer code: </h1>
    </>
  );
};

export default UserRefer;
