import React from "react";

const UserPromotions = () => {
  return (
    <>
      <h1>My promotions </h1>
    </>
  );
};

export default UserPromotions;
